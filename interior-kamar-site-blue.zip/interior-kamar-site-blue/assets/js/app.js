const sliderTrack = document.querySelector('.slider-track');
document.querySelector('.prev').addEventListener('click', ()=>{ sliderTrack.scrollBy({left:-220, behavior:'smooth'}); });
document.querySelector('.next').addEventListener('click', ()=>{ sliderTrack.scrollBy({left:220, behavior:'smooth'}); });

const form = document.getElementById('kritikForm');
const list = document.getElementById('kritikList');
form.addEventListener('submit', e=>{
  e.preventDefault();
  const nama = form.nama.value.trim();
  const pesan = form.pesan.value.trim();
  if(!nama || !pesan) return;
  const div = document.createElement('div');
  div.className='kritik-item';
  div.innerHTML=`<strong>${nama}</strong><p>${pesan}</p>`;
  list.prepend(div);
  form.reset();
});